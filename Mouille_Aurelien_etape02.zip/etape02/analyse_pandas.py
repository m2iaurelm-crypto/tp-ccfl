import pandas as pd 
from collections import Counter
from pathlib import Path

csvpath_associations = "./data/associations.csv"
csvpath_materiel = "./data/materiel.csv"
csvpath_reservations = "./data/reservations.csv"
csvpath_sites = "./data/sites.csv"
csvpath_top10 = "./sorties/top10_materiel.csv"


df_associations = pd.read_csv(csvpath_associations)
df_materiel = pd.read_csv(csvpath_materiel)
df_reservations = pd.read_csv(csvpath_reservations)
df_sites = pd.read_csv(csvpath_sites)

# Les décimales de valeur_achat utilisent une virgule, ce qui empêche leur lecture numérique.
df_materiel["valeur_achat"] = pd.to_numeric(
    df_materiel["valeur_achat"].str.replace(",", ".", regex=False)
)



nb_manquants_materiel = df_materiel.isna().sum()

nb_manquants_reservations = df_reservations.isna().sum()
print("Infos du df materiel :")
print(df_materiel.info())
print(df_materiel.shape)

print("\nNombre de valeurs manquantes par colonnes sur le df materiel :")
print(nb_manquants_materiel)

print("\nInfos du df reservations : ")
print(df_reservations.info())
print(df_reservations.shape)
print("\nNombre de valeurs manquantes par colonnes sur le df reservations :")
print(nb_manquants_reservations)

print("Les 10 matériels les plus chers :")
print(df_materiel[["reference", "designation", "categorie", "valeur_achat"]].sort_values("valeur_achat", ascending=False).head(10)
)

print("\nNombre de matériels par catégorie :")

print(df_materiel.groupby("categorie").size().sort_values(ascending=False))

print("\nNombre de réservations et quantité totale par site :")

reservations_par_site = (df_reservations.groupby("code_site").agg(nombre_reservations=("id_reservation", "count"),quantite_totale=("quantite", "sum"),).sort_values("nombre_reservations", ascending=False)
)
print(reservations_par_site)

df_complet = pd.merge(df_reservations,df_materiel.drop_duplicates(),how="left",on="id_materiel",indicator=True)
df_complet = pd.merge(df_complet,df_associations,how="left",on="id_association")

print(f"\nNombre de lignes dans df_complet : {len(df_complet)}")
print(
    "Nombre de réservations sans matériel correspondant : "
    f"{len(df_complet[df_complet['_merge'] == 'left_only'])}"
)

df_top10 = (df_complet.groupby(["id_materiel", "designation"]).size().reset_index(name="nombre_reservations").sort_values("nombre_reservations", ascending=False).head(10)
)

print("\nTop 10 des matériels les plus réservés :")
print(df_top10)

Path("sorties").mkdir(exist_ok=True)
df_top10.to_csv(csvpath_top10, index=False, encoding="UTF-8")
