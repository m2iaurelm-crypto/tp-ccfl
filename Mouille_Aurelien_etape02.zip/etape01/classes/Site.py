class Site:
    def __init__(self,code_site: str,nom: str,commune: str,annee_ouverture: int,surface_m2: int,):
        self.code_site = code_site
        self.nom = nom
        self.commune = commune
        self.annee_ouverture = int(annee_ouverture)
        self.surface_m2 = int(surface_m2)

    def anciennete(self, annee_reference):
        return annee_reference - self.annee_ouverture

    def __str__(self):
        return (
            f"{self.code_site} - {self.nom} ({self.commune}), "
            f"{self.surface_m2} m2"
        )