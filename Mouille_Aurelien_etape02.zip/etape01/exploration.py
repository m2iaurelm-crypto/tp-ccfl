import csv
from collections import Counter
from operator import itemgetter
from classes.Site import Site

csvpath_association = "./data/associations.csv"
csvpath_materiel = "./data/materiel.csv"
csvpath_reservations = "./data/reservations.csv"
csvpath_sites = "./data/sites.csv"


def lire_csv(chemin):
    with open(chemin, newline="", encoding="UTF-8") as file:
        reader = csv.DictReader(file)
        lignes = []
        for ligne in reader:
            lignes.append(ligne)
    return lignes


def compter_par(lignes: list[dict], colonne: str):
    compteur = Counter()
    for ligne in lignes:
        compteur[ligne[colonne]] += 1
    return compteur


def total_par(lignes: list[dict], colonne_groupe: str, colonne_valeur: str):
    totaux = Counter()
    for ligne in lignes:
        totaux[ligne[colonne_groupe]] += int(ligne[colonne_valeur])
    return totaux


def reservations_en_cours(reservations: list):
    return [
        reservation
        for reservation in reservations
        if reservation["date_retour_reelle"].strip() == ""
    ]


def main():
    sites = lire_csv(csvpath_sites)
    materiels = lire_csv(csvpath_materiel)
    associations = lire_csv(csvpath_association)
    reservations = lire_csv(csvpath_reservations)

    print("Nombre de lignes par fichier :")
    print(f"Sites : {len(sites)}")
    print(f"Matériels : {len(materiels)}")
    print(f"Associations : {len(associations)}")
    print(f"Réservations : {len(reservations)}")

    print("\nSites et ancienneté en 2026 :")
    sites_objets = []
    for ligne in sites:
        sites_objets.append(
            Site(
                ligne["code_site"],
                ligne["nom"],
                ligne["commune"],
                ligne["annee_ouverture"],
                ligne["surface_m2"],
            )
        )
    for site in sites_objets:
        print(f"{site} - ancienneté : {site.anciennete(2026)} ans")

    print("\nNombre de réservations par site :")
    reservations_par_site = compter_par(reservations, "code_site")
    for code_site, nombre in sorted(reservations_par_site.items(), key=itemgetter(1), reverse=True):
        print(f"{code_site} : {nombre}")

    print("\nQuantité totale réservée par site :")
    quantite_par_site = total_par(reservations, "code_site", "quantite")
    for code_site, quantite in sorted(quantite_par_site.items(), key=itemgetter(1), reverse=True):
        print(f"{code_site} : {quantite}")

    print("\nNombre de matériels par état :")
    materiels_par_etat = compter_par(materiels, "etat")
    for etat, nombre in materiels_par_etat.items():
        print(f"{etat} : {nombre}")

    categories = compter_par(materiels, "categorie")
    print(f"\nNombre de valeurs distinctes de catégorie : {len(categories)}")

    reservations_actuelles = reservations_en_cours(reservations)
    print(f"\nNombre de réservations en cours : {len(reservations_actuelles)}")


if __name__ == "__main__":
    main()
