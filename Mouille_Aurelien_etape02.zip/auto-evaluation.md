# Auto-évaluation — Mouille Aurélien

## Étapes

| Étape | État (terminée / partielle / non abordée) | Points de vérification obtenus | Ce qui a bloqué | Temps réel passé par étape |
|---|---|---|---|---|
| 1 | terminée| ---- |   | ~ 1h |
| 2 | terminée | ---- | | ~ 1h |
| 3 | | | | |
| 4 | | | | |
| 5 | | | | |
| 6 | | | | |
| 7 | | | | |

## Ce que je sais faire mieux qu'en septembre
(3 lignes)

## Ce qui me résiste encore
(3 lignes)