# Rapport de qualité des données — Prêt de matériel CCFL

Date de génération : 06/11/2026

## Anomalies détectées et traitements retenus

| Fichier | Colonne | Description | Nombre de lignes | Part du fichier | Traitement retenu |
|---|---|---|---:|---:|---|
| `materiel.csv` | `ligne entière` | Doublons stricts | 7 | 1.91 % | Suppression des doublons stricts, une occurrence conservée. |
| `materiel.csv` | `annee_achat` | Année d'achat manquante | 9 | 2.45 % | Valeur manquante conservée, sans inventer d'année. |
| `materiel.csv` | `annee_achat` | Année d'achat postérieure à l'année courante | 5 | 1.36 % | Valeur remplacée par une valeur manquante en attendant vérification. |
| `materiel.csv` | `valeur_achat` | Valeur d'achat manquante | 11 | 3.00 % | Valeur manquante conservée, sans la remplacer par zéro. |
| `materiel.csv` | `categorie` | Catégorie écrite intégralement en majuscules | 6 | 1.63 % | Casse normalisée vers le libellé homogène attendu. |
| `materiel.csv` | `categorie` | Espaces parasites autour de la catégorie | 5 | 1.36 % | Espaces de début et de fin supprimés. |
| `materiel.csv` | `valeur_achat` | Virgule utilisée comme séparateur décimal | 5 | 1.36 % | Virgule remplacée par un point et valeur convertie en nombre. |
| `associations.csv` | `code_postal` | Code postal manquant | 9 | 4.29 % | Valeur manquante conservée, sans inventer de code postal. |
| `associations.csv` | `type_association` | Type d'association indiqué comme inconnu | 7 | 3.33 % | Valeur conservée et signalée, le type réel est inconnu. |
| `associations.csv` | `date_convention` | Date au format JJ/MM/AAAA | 6 | 2.86 % | Date convertie au format ISO AAAA-MM-JJ. |
| `reservations.csv` | `ligne entière` | Doublons stricts | 18 | 0.39 % | Suppression des doublons stricts, une occurrence conservée. |
| `reservations.csv` | `id_materiel` | Matériel inexistant | 21 | 0.45 % | Réservation écartée pour préserver le lien vers le matériel. |
| `reservations.csv` | `date_retour_reelle` | Retour antérieur au début du prêt | 15 | 0.32 % | Réservation écartée, la chronologie est impossible. |
| `reservations.csv` | `quantite` | Quantité égale à zéro | 6 | 0.13 % | Réservation écartée, elle ne correspond pas à un prêt effectif. |

Les prêts sans date de retour réelle sont une situation normale : ils sont conservés et ne sont pas comptés parmi les anomalies.

## Nombre de lignes avant et après nettoyage

| Fichier | Avant | Après |
|---|---:|---:|
| `materiel.csv` | 367 | 360 |
| `associations.csv` | 210 | 210 |
| `reservations.csv` | 4618 | 4560 |

## Prêts en cours

Avant nettoyage : 72. Après nettoyage : 71. L'écart de 1 prêt s'explique par la suppression d'une réservation en cours dont la quantité était nulle.

## Points d'attention pour la direction

- Sept lignes de matériel étaient des copies strictement identiques et ont été dédoublonnées.
- Les catégories ont été harmonisées pour faciliter les comparaisons entre pôles.
- Les années d'achat futures restent à vérifier auprès des équipes concernées.
- Les prix absents et les codes postaux manquants n'ont pas été remplacés par des valeurs inventées.
- Certaines associations ont un type indiqué comme inconnu ; une vérification métier est nécessaire.
- Des réservations faisaient référence à du matériel absent du fichier d'inventaire.
- Des retours étaient datés avant le début du prêt, ce qui doit être vérifié avec les justificatifs.
- Les réservations de quantité nulle ont été écartées des données utilisables.
- Les prêts sans date de retour sont conservés : le matériel n'est pas encore revenu.
