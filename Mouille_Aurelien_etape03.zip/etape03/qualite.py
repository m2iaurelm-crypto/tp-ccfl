import pandas as pd 
from datetime import date 
from pathlib import Path

csvpath_associations = "./data/associations.csv"
csvpath_materiel = "./data/materiel.csv"
csvpath_reservations = "./data/reservations.csv"

df_associations = pd.read_csv(csvpath_associations, dtype={"code_postal": "string"})
df_materiel = pd.read_csv(csvpath_materiel)
df_reservations = pd.read_csv(csvpath_reservations)
nombre_materiel_avant = len(df_materiel)
nombre_associations_avant = len(df_associations)
nombre_reservations_avant = len(df_reservations)

annee_en_cours = date.today().year

doublons_materiel = df_materiel[df_materiel.duplicated()]
print("Lignes en doublon strict dans materiel.csv :", len(doublons_materiel))
print(doublons_materiel.head(3))

annee_achat_vide = df_materiel[df_materiel["annee_achat"].isna()]
print("\nAnnee d'achat vide :", len(annee_achat_vide))
print(annee_achat_vide.head(3))

annee_achat_future = df_materiel[df_materiel["annee_achat"] > annee_en_cours]
print("\nAnnee d'achat posterieure a l'annee courante :", len(annee_achat_future))
print(annee_achat_future.head(3))

valeur_achat_vide = df_materiel[df_materiel["valeur_achat"].isna()]
print("\nValeur d'achat vide :", len(valeur_achat_vide))
print(valeur_achat_vide.head(3))

categorie_majuscules = df_materiel[df_materiel["categorie"].str.isupper()]
print("\nCategorie ecrite integralement en majuscules :", len(categorie_majuscules))
print(categorie_majuscules.head(3))

categorie_espaces = df_materiel[df_materiel["categorie"] != df_materiel["categorie"].str.strip()]
print("\nCategorie avec des espaces parasites :", len(categorie_espaces))
print(categorie_espaces.head(3))

valeur_virgule = df_materiel[df_materiel["valeur_achat"].str.contains(",", na=False)]
print("\nValeur d'achat avec une virgule decimale :", len(valeur_virgule))
print(valeur_virgule.head(3))

code_postal_vide = df_associations[df_associations["code_postal"].isna()]
print("\nCode postal vide :", len(code_postal_vide))
print(code_postal_vide.head(3))

type_inconnu = df_associations[df_associations["type_association"].str.strip().str.lower() == "inconnu"]
print("\nType d'association inconnu :", len(type_inconnu))
print(type_inconnu.head(3))

date_convention_format_invalide = df_associations[df_associations["date_convention"].str.contains(r"^\d{2}/\d{2}/\d{4}$", na=False)]
print("\nDate de convention au format JJ/MM/AAAA :", len(date_convention_format_invalide))
print(date_convention_format_invalide.head(3))

doublons_reservations = df_reservations[df_reservations.duplicated()]
print("\nLignes en doublon strict dans reservations.csv :", len(doublons_reservations))
print(doublons_reservations.head(3))

materiel_inexistant = df_reservations[~df_reservations["id_materiel"].isin(df_materiel["id_materiel"])]
print("\nReservation avec un id_materiel inexistant :", len(materiel_inexistant))
print(materiel_inexistant.head(3))

df_reservations["date_debut"] = pd.to_datetime(df_reservations["date_debut"], errors="coerce")
df_reservations["date_retour_reelle"] = pd.to_datetime(df_reservations["date_retour_reelle"], errors="coerce")
date_retour_avant_debut = df_reservations[df_reservations["date_retour_reelle"] < df_reservations["date_debut"]]
print("\nDate de retour reelle anterieure a la date de debut :", len(date_retour_avant_debut))
print(date_retour_avant_debut.head(3))

quantite_zero = df_reservations[df_reservations["quantite"] == 0]
print("\nReservation avec une quantite egale a zero :", len(quantite_zero))
print(quantite_zero.head(3))

reservations_en_cours = df_reservations[df_reservations["date_retour_reelle"].isna()]
print("\nPrets en cours (cas metier normal, pas une anomalie) :", len(reservations_en_cours))

print("\nDecisions de traitement des anomalies :")
print("Doublons stricts de materiel : supprimer les repetitions et conserver une occurrence, car les lignes sont identiques.")
print("Annee d'achat vide : conserver la valeur manquante et la signaler, car aucune annee ne peut etre devinee.")
print("Annee d'achat future : remplacer par une valeur manquante et signaler, car l'annee exacte doit etre verifiee.")
print("Valeur d'achat vide : conserver la valeur manquante et la signaler, sans la remplacer par zero.")
print("Categorie en majuscules : normaliser vers le libelle attendu, car seule la casse differe.")
print("Categorie avec espaces parasites : supprimer les espaces de debut et de fin, sans changer le libelle.")
print("Valeur d'achat avec virgule decimale : remplacer la virgule par un point et convertir en nombre.")
print("Code postal vide : conserver la valeur manquante et la signaler, sans inventer de code postal.")
print("Type d'association inconnu : conserver la valeur et la signaler, car le type reel n'est pas connu.")
print("Date de convention au format JJ/MM/AAAA : convertir en date ISO en respectant le jour et le mois.")
print("Doublons stricts de reservations : supprimer les repetitions et conserver une occurrence.")
print("Reservation avec un materiel inexistant : supprimer la reservation, car elle ne peut pas respecter la cle etrangere.")
print("Date de retour anterieure au debut : supprimer la reservation, car la chronologie est impossible et la correction est inconnue.")
print("Reservation de quantite nulle : supprimer la reservation, car elle ne correspond a aucun pret effectif.")
print("Prets en cours : conserver les lignes sans date de retour, car elles representent des prets normaux non encore rendus.")

prets_en_cours_avant = len(reservations_en_cours)

df_materiel = df_materiel.drop_duplicates()
df_materiel["categorie"] = df_materiel["categorie"].str.strip().str.capitalize()
df_materiel["valeur_achat"] = pd.to_numeric(df_materiel["valeur_achat"].str.replace(",", ".", regex=False), errors="coerce")
df_materiel["annee_achat"] = df_materiel["annee_achat"].mask(df_materiel["annee_achat"] > annee_en_cours)

df_associations["date_convention"] = pd.to_datetime(df_associations["date_convention"], format="mixed", dayfirst=True, errors="coerce").dt.strftime("%Y-%m-%d")

df_reservations = df_reservations.drop_duplicates()
df_reservations = df_reservations[df_reservations["id_materiel"].isin(df_materiel["id_materiel"])]
df_reservations = df_reservations[df_reservations["date_retour_reelle"].isna() | (df_reservations["date_retour_reelle"] >= df_reservations["date_debut"])]
df_reservations = df_reservations[df_reservations["quantite"] != 0]

prets_en_cours_apres = len(df_reservations[df_reservations["date_retour_reelle"].isna()])
nombre_materiel_apres = len(df_materiel)
nombre_associations_apres = len(df_associations)
nombre_reservations_apres = len(df_reservations)

Path("sorties").mkdir(exist_ok=True)
df_materiel.to_csv("sorties/materiel_propre.csv", encoding="UTF-8", index=False)
df_associations.to_csv("sorties/associations_propre.csv", encoding="UTF-8", index=False)
df_reservations.to_csv("sorties/reservations_propre.csv", encoding="UTF-8", index=False)

anomalies = [
    ("materiel.csv", "ligne entière", "Doublons stricts", len(doublons_materiel), nombre_materiel_avant, "Suppression des doublons stricts, une occurrence conservée."),
    ("materiel.csv", "annee_achat", "Année d'achat manquante", len(annee_achat_vide), nombre_materiel_avant, "Valeur manquante conservée, sans inventer d'année."),
    ("materiel.csv", "annee_achat", "Année d'achat postérieure à l'année courante", len(annee_achat_future), nombre_materiel_avant, "Valeur remplacée par une valeur manquante en attendant vérification."),
    ("materiel.csv", "valeur_achat", "Valeur d'achat manquante", len(valeur_achat_vide), nombre_materiel_avant, "Valeur manquante conservée, sans la remplacer par zéro."),
    ("materiel.csv", "categorie", "Catégorie écrite intégralement en majuscules", len(categorie_majuscules), nombre_materiel_avant, "Casse normalisée vers le libellé homogène attendu."),
    ("materiel.csv", "categorie", "Espaces parasites autour de la catégorie", len(categorie_espaces), nombre_materiel_avant, "Espaces de début et de fin supprimés."),
    ("materiel.csv", "valeur_achat", "Virgule utilisée comme séparateur décimal", len(valeur_virgule), nombre_materiel_avant, "Virgule remplacée par un point et valeur convertie en nombre."),
    ("associations.csv", "code_postal", "Code postal manquant", len(code_postal_vide), nombre_associations_avant, "Valeur manquante conservée, sans inventer de code postal."),
    ("associations.csv", "type_association", "Type d'association indiqué comme inconnu", len(type_inconnu), nombre_associations_avant, "Valeur conservée et signalée, le type réel est inconnu."),
    ("associations.csv", "date_convention", "Date au format JJ/MM/AAAA", len(date_convention_format_invalide), nombre_associations_avant, "Date convertie au format ISO AAAA-MM-JJ."),
    ("reservations.csv", "ligne entière", "Doublons stricts", len(doublons_reservations), nombre_reservations_avant, "Suppression des doublons stricts, une occurrence conservée."),
    ("reservations.csv", "id_materiel", "Matériel inexistant", len(materiel_inexistant), nombre_reservations_avant, "Réservation écartée pour préserver le lien vers le matériel."),
    ("reservations.csv", "date_retour_reelle", "Retour antérieur au début du prêt", len(date_retour_avant_debut), nombre_reservations_avant, "Réservation écartée, la chronologie est impossible."),
    ("reservations.csv", "quantite", "Quantité égale à zéro", len(quantite_zero), nombre_reservations_avant, "Réservation écartée, elle ne correspond pas à un prêt effectif."),
]

lignes_tableau = []
for fichier, colonne, description, nombre, total, traitement in anomalies:
    part = nombre / total * 100
    lignes_tableau.append(f"| `{fichier}` | `{colonne}` | {description} | {nombre} | {part:.2f} % | {traitement} |")

markdown_content = f"""# Rapport de qualité des données — Prêt de matériel CCFL

Date de génération : {date.today().strftime("%d/%m/%Y")}

## Anomalies détectées et traitements retenus

| Fichier | Colonne | Description | Nombre de lignes | Part du fichier | Traitement retenu |
|---|---|---|---:|---:|---|
{chr(10).join(lignes_tableau)}

Les prêts sans date de retour réelle sont une situation normale : ils sont conservés et ne sont pas comptés parmi les anomalies.

## Nombre de lignes avant et après nettoyage

| Fichier | Avant | Après |
|---|---:|---:|
| `materiel.csv` | {nombre_materiel_avant} | {nombre_materiel_apres} |
| `associations.csv` | {nombre_associations_avant} | {nombre_associations_apres} |
| `reservations.csv` | {nombre_reservations_avant} | {nombre_reservations_apres} |

## Prêts en cours

Avant nettoyage : {prets_en_cours_avant}. Après nettoyage : {prets_en_cours_apres}. L'écart de {prets_en_cours_avant - prets_en_cours_apres} prêt s'explique par la suppression d'une réservation en cours dont la quantité était nulle.

## Points d'attention pour la direction

- Sept lignes de matériel étaient des copies strictement identiques et ont été dédoublonnées.
- Les catégories ont été harmonisées pour faciliter les comparaisons entre pôles.
- Les années d'achat futures restent à vérifier auprès des équipes concernées.
- Les prix absents et les codes postaux manquants n'ont pas été remplacés par des valeurs inventées.
- Certaines associations ont un type indiqué comme inconnu ; une vérification métier est nécessaire.
- Des réservations faisaient référence à du matériel absent du fichier d'inventaire.
- Des retours étaient datés avant le début du prêt, ce qui doit être vérifié avec les justificatifs.
- Les réservations de quantité nulle ont été écartées des données utilisables.
- Les prêts sans date de retour sont conservés : le matériel n'est pas encore revenu.
"""

with open("sorties/rapport_qualite.md", "w", encoding="UTF-8") as file:
    file.write(markdown_content)
