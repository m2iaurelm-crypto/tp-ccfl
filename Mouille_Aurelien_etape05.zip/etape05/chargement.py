import logging
import os
from pathlib import Path

import pandas as pd
from dotenv import load_dotenv
from sqlalchemy import create_engine, inspect, text

BASE_DIR = Path(__file__).resolve().parents[1]
load_dotenv(BASE_DIR / ".env")
DATABASE_URL = os.getenv("DATABASE_URL")
if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL est absente du fichier .env ou de l'environnement.")
engine = create_engine(DATABASE_URL, pool_pre_ping=True)

logging.basicConfig(
    filename=BASE_DIR / "sorties" / "chargement.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

FICHIERS = {
    "site": BASE_DIR / "data" / "sites.csv",
    "materiel": BASE_DIR / "sorties" / "materiel_propre.csv",
    "association": BASE_DIR / "sorties" / "associations_propre.csv",
    "reservation": BASE_DIR / "sorties" / "reservations_propre.csv",
}


def get_primary_key(table: str) -> str:
    colonnes = inspect(engine).get_pk_constraint(table)["constrained_columns"]
    return colonnes[0]


def insert_df_to_sql(table: str, dataframe: pd.DataFrame) -> None:
    pk = get_primary_key(table)
    with engine.begin() as conn:
        ids_existants = pd.read_sql(text(f"SELECT {pk} FROM {table}"), con=conn)[pk]
        nouvelles_lignes = dataframe[~dataframe[pk].isin(ids_existants)]
        if nouvelles_lignes.empty:
            message = f"{table} : aucune nouvelle ligne ({len(dataframe)} déjà présentes)."
        else:
            nouvelles_lignes.to_sql(table, con=conn, if_exists="append", index=False)
            message = f"{table} : {len(nouvelles_lignes)} lignes ajoutées."
        logging.info(message)
        print(message)


def main() -> None:
    logging.info("Début du chargement des données CCFL.")
    for table, chemin in FICHIERS.items():
        options = {"dtype": {"code_postal": "string"}} if table == "association" else {}
        dataframe = pd.read_csv(chemin, **options)
        if table == "association":
            dataframe["convention_active"] = dataframe["convention_active"].map(
                {"oui": True, "non": False}
            )
        try:
            insert_df_to_sql(table, dataframe)
        except Exception:
            logging.exception("Erreur lors du chargement de la table %s.", table)
            raise
    engine.dispose()
    logging.info("Fin du chargement des données CCFL.")


if __name__ == "__main__":
    main()
