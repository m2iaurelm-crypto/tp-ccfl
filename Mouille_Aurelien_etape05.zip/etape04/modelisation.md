# Modélisation des données — Prêt de matériel CCFL

## MCD

### Entités et propriétés

- **SITE** : `code_site`, `nom`, `commune`, `annee_ouverture`, `surface_m2`
- **MATERIEL** : `id_materiel`, `reference`, `designation`, `categorie`, `etat`, `annee_achat`, `code_site`, `valeur_achat`
- **ASSOCIATION** : `id_association`, `nom`, `type_association`, `commune`, `code_postal`, `date_convention`, `code_site`, `convention_active`
- **RESERVATION** : `id_reservation`, `id_materiel`, `id_association`, `code_site`, `quantite`, `date_debut`, `date_fin_prevue`, `date_retour_reelle`

### Associations et cardinalités

![MCD CCFL réalisé avec Looping](./MCD_looping.png)

### Détail des cardinalités

Les cardinalités ci-dessous donnent le minimum et le maximum de participations de chaque entité à une association :

| Association | Première entité | Seconde entité | Explication |
|---|---|---|---|
| **SITE stocke MATERIEL** | SITE : `0..N` matériels | MATERIEL : `1..1` site | Un site peut ne stocker encore aucun matériel ou en stocker plusieurs. Chaque matériel est stocké dans un seul site. |
| **SITE rattache ASSOCIATION** | SITE : `0..N` associations | ASSOCIATION : `1..1` site | Un site peut n'avoir aucune association rattachée ou en avoir plusieurs. Chaque association est rattachée à un seul site. |
| **SITE accueille RESERVATION** | SITE : `0..N` réservations | RESERVATION : `1..1` site | Un site peut n'accueillir aucune réservation ou en accueillir plusieurs. Chaque réservation indique un seul site de retrait. |
| **ASSOCIATION effectue RESERVATION** | ASSOCIATION : `0..N` réservations | RESERVATION : `1..1` association | Une association peut n'avoir encore effectué aucune réservation ou en effectuer plusieurs. Chaque réservation est faite par une seule association. |
| **MATERIEL concerne RESERVATION** | MATERIEL : `0..N` réservations | RESERVATION : `1..1` matériel | Un matériel peut n'avoir jamais été réservé ou apparaître dans plusieurs réservations. Chaque réservation concerne un seul matériel. |

Ainsi, `||` signifie « exactement un » et `o{` signifie « zéro, un ou plusieurs ». Les réservations ont des liens obligatoires vers leur site, leur association et leur matériel ; inversement, ces entités peuvent exister sans réservation ni élément rattaché.

## MLD

![MLD CCFL réalisé avec Looping](./MLD_Looping.png)

- **SITE** (`code_site` CHAR(7) **PK**, `nom` VARCHAR(100), `commune` VARCHAR(100), `annee_ouverture` INTEGER, `surface_m2` INTEGER)
- **MATERIEL** (`id_materiel` INTEGER **PK**, `reference` VARCHAR(20), `designation` VARCHAR(150), `categorie` VARCHAR(50), `etat` VARCHAR(30), `annee_achat` INTEGER NULL, `code_site` CHAR(7) **FK** → SITE, `valeur_achat` NUMERIC(10,2) NULL)
- **ASSOCIATION** (`id_association` INTEGER **PK**, `nom` VARCHAR(150), `type_association` VARCHAR(30), `commune` VARCHAR(100), `code_postal` VARCHAR(5) NULL, `date_convention` DATE, `code_site` CHAR(7) **FK** → SITE, `convention_active` BOOLEAN)
- **RESERVATION** (`id_reservation` CHAR(7) **PK**, `id_materiel` INTEGER **FK** → MATERIEL, `id_association` INTEGER **FK** → ASSOCIATION, `code_site` CHAR(7) **FK** → SITE, `quantite` INTEGER, `date_debut` DATE, `date_fin_prevue` DATE, `date_retour_reelle` DATE NULL)

Les colonnes obligatoires sont `NOT NULL` dans le DDL. Les seuls attributs facultatifs sont les années et valeurs d'achat éventuellement absentes, le code postal manquant et la date de retour d'un prêt en cours.

Le schéma ajoute des contraintes `CHECK` pour les formats des identifiants, les codes postaux, les catégories, les états et les types d'association. Il impose également des surfaces et valeurs d'achat non négatives, des années cohérentes avec la période des données (1900–2026), une quantité strictement positive et des dates de retour cohérentes. La valeur `inconnu` reste autorisée pour le type d'association, car elle est présente dans les données nettoyées et doit être conservée avec signalement.

## Justifications

1. `id_reservation` est défini en `CHAR(7)`, car les identifiants tels que `R250000` contiennent une lettre et ont une longueur fixe.
2. Le conserver comme texte évite de perdre le préfixe et permet de garder exactement l'identifiant source.
3. `valeur_achat` utilise `NUMERIC(10,2)`, adapté à un montant exprimé en euros et centimes.
4. Un type flottant est déconseillé pour l'argent, car sa représentation binaire peut introduire des erreurs d'arrondi.
5. `convention_active` devient un booléen : les valeurs source `oui` et `non` représentent deux états sans troisième valeur.
6. Le chargement convertira `oui` en `TRUE` et `non` en `FALSE`.
7. `date_retour_reelle` accepte `NULL`, car l'absence de date signifie que le prêt est encore en cours.
8. Les dates de début et de retour prévues restent obligatoires pour toute réservation.
9. `code_site` dans `materiel` indique où le bien est stocké.
10. `code_site` dans `association` indique le pôle auquel l'association est rattachée.
11. `code_site` dans `reservation` indique le pôle où le retrait a lieu pour cette réservation.
12. Ces trois attributs ne sont donc pas redondants : ils décrivent trois informations métier différentes.
13. Chaque `code_site` est une clé étrangère vers `site`, ce qui interdit les codes de pôle inconnus.
14. Les clés étrangères de réservation assurent l'existence du matériel, de l'association et du pôle référencés.
15. La date de fin prévue ne peut précéder la date de début, et la quantité réservée doit être strictement positive.
