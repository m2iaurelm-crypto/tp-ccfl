-- Creer la base avant l'execution : createdb ccfl
-- Executer avec : psql -d ccfl -f etape04/schema.sql

-- Suppression dans l'ordre inverse des dependances pour permettre une reexecution.
DROP TABLE IF EXISTS reservation;
DROP TABLE IF EXISTS association;
DROP TABLE IF EXISTS materiel;
DROP TABLE IF EXISTS site;

CREATE TABLE site (
    code_site CHAR(7) PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    commune VARCHAR(100) NOT NULL,
    annee_ouverture INTEGER NOT NULL CHECK (annee_ouverture BETWEEN 1900 AND 2026),
    surface_m2 INTEGER NOT NULL CHECK (surface_m2 > 0),
    CONSTRAINT ck_site_code_format CHECK (code_site ~ '^POL-[A-Z]{3}$')
);

CREATE TABLE materiel (
    id_materiel INTEGER PRIMARY KEY,
    reference VARCHAR(20) NOT NULL ,
    designation VARCHAR(150) NOT NULL,
    categorie VARCHAR(50) NOT NULL CHECK (categorie IN ('Sonorisation', 'Mobilier', 'Tente et barnum', 'Eclairage', 'Securite', 'Cuisine')),
    etat VARCHAR(30) NOT NULL CHECK (etat IN ('neuf', 'bon', 'moyen', 'a reviser')),
    annee_achat INTEGER CHECK (annee_achat IS NULL OR annee_achat BETWEEN 1900 AND 2026),
    code_site CHAR(7) NOT NULL,
    valeur_achat NUMERIC(10, 2) CHECK (valeur_achat IS NULL OR valeur_achat >= 0),
    CONSTRAINT fk_materiel_site FOREIGN KEY (code_site) REFERENCES site(code_site)
);

CREATE TABLE association (
    id_association INTEGER PRIMARY KEY,
    nom VARCHAR(150) NOT NULL,
    type_association VARCHAR(30) NOT NULL CHECK (type_association IN ('sportive', 'culturelle', 'sociale', 'festive', 'scolaire', 'inconnu')),
    commune VARCHAR(100) NOT NULL,
    code_postal VARCHAR(5) CHECK (code_postal IS NULL OR code_postal ~ '^[0-9]{5}$'),
    date_convention DATE NOT NULL,
    code_site CHAR(7) NOT NULL,
    convention_active BOOLEAN NOT NULL,
    CONSTRAINT fk_association_site FOREIGN KEY (code_site) REFERENCES site(code_site)
);

CREATE TABLE reservation (
    id_reservation CHAR(7) PRIMARY KEY CHECK (id_reservation ~ '^R[0-9]{6}$'),
    id_materiel INTEGER NOT NULL,
    id_association INTEGER NOT NULL,
    code_site CHAR(7) NOT NULL,
    quantite INTEGER NOT NULL CHECK (quantite > 0),
    date_debut DATE NOT NULL,
    date_fin_prevue DATE NOT NULL,
    date_retour_reelle DATE,
    CHECK (date_fin_prevue >= date_debut),
    CHECK (date_retour_reelle IS NULL OR date_retour_reelle >= date_debut),
    CONSTRAINT fk_reservation_materiel FOREIGN KEY (id_materiel) REFERENCES materiel(id_materiel),
    CONSTRAINT fk_reservation_association FOREIGN KEY (id_association) REFERENCES association(id_association),
    CONSTRAINT fk_reservation_site FOREIGN KEY (code_site) REFERENCES site(code_site)
);

-- Ces index accélèrent les analyses temporelles et le regroupement des réservations par matériel.
CREATE INDEX IF NOT EXISTS idx_reservation_date_debut ON reservation(date_debut);
CREATE INDEX IF NOT EXISTS idx_reservation_id_materiel ON reservation(id_materiel);
